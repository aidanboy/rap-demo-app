import { useEffect, useState } from 'react';
import { Person } from './Person';

export const People = () => {
  const [people, setPeople] = useState([]);
  useEffect(() => {
    fetch(`https://randomuser.me/api/?results=10`)
      .then(res => res.json())
      .then(res => res.results)
      .then(people => setPeople(people));
  }, []);

  return (
    <>
      <h1>All the people</h1>
      <section style={styles.wrapper}>
        {people.map(person => <Person person={person} foo="bar" key={person.email} />)}
      </section>
    </>
  );
}

const styles = {
  wrapper: {
    display: "flex",
    flexWrap: "wrap",
  },
}