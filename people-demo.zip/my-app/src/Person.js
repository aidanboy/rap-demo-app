export const Person = ({ person }) => (
  <section style={styles.personCard}>
    <div style={styles.cardHeader}>
      <img src={person.picture?.large} alt="" style={styles.image} />
      <h2 style={styles.personName}>{person.name?.first} {person.name?.last}</h2>
    </div>
    <p style={styles.personDetails}>email: {person.email}</p>
    <p style={styles.personDetails}>cell: {person.cell}</p>
  </section>
)


const styles = {
  personCard: {
    width: 300,
    margin: 25,
    backgroundColor: "white",
    boxShadow: '5px 5px 5px grey'
  },
  cardHeader: {
    position: "relative",
    height: 300,
  },
  image: {
    width: "100%",
    position: "absolute",
  },
  personName: {
    position: "absolute",
    top: 0, left: 0, right: 0,
    background: 'linear-gradient(0deg, rgba(0,0,0,0) 0%, rgba(0,0,0,1) 100%)',
    color: 'white',
    marginTop: 0,
    height: "3em",
    display: "flex", justifyContent: "center", alignItems: "center",
  },
  personDetails: {
    fontWeight: "bold",
    paddingLeft: 5,
  }
}