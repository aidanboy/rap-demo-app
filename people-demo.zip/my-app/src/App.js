import './App.css';
import { People } from './people';

function App() {
  return (
    <>
      <header>
        <h1>Demo app</h1>
      </header>
      <main>
        <People />
      </main>
      <footer></footer>
    </>
  );
}

export default App;
